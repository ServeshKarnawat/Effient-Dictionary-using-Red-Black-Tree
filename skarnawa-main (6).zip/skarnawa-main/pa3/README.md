//Servesh Karnawat
//skarnawa
//pa3
Makefile: creates rules to determine which parts of the program need to be recompiled
List.h: instantiates all the functions for the  doubly linked list
List.c: contains actual code defining the functions for the doubly linked list
Graph.h: instatiates all the functions for the graph ADT
Graph.c: contains the actual code definind the functions for the graph ADT
GraphTest.c: testing space to test functions made in Graph.c
FindComponents.c: Takes in an input file and output file and uses the arcs provided in the input file in order to create a directed graph and finds the strongly connected componenets of the directed graph.
Note on Graph.c: I used a global variable to reference the time of each discover and finish of the graph. 