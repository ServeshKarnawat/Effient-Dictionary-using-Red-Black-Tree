//Servesh Karnawat
//skarnawa
//Pa6


#include "List.h"

int main(){
    List A = List();
    List B = List();
    List C = List();

    std::cout << A.length();
    A.insertAfter(3);
    std::cout << A.length();
    std::cout << A.peekPrev();
    std::cout << A.peekNext();
    A.insertAfter(10);
    A.insertAfter(30);
    A.insertAfter(3);
    std::cout << A.to_string();
    A.moveFront();
    A.moveNext();
    A.moveNext();
    A.eraseBefore();
    std::cout << A.to_string();
    A.insertBefore(100);
    A.insertBefore(100);
    A.insertBefore(100);
    A.insertBefore(100);
    std::cout << A.to_string();
    A.cleanup();
    std::cout << A.to_string();
    std::cout << A.findNext(100);
    std::cout << A.findNext(30);
    std::cout << A.findPrev(100);



    


    /*
    A.insertAfter(1);
    A.insertAfter(2);
    A.insertAfter(3);
    B.insertAfter(4);
    B.insertAfter(5);
    B.insertAfter(6);

    C = A.concat(B);
    if (C.length() != 6)
        return 1;
    



    return 0;
    */

    
    std::cout << "current pos:" << A.position()<< "\n";
    A.insertBefore(1);
    std::cout << "current pos:" << A.position()<< "\n";

    A.insertAfter(2);
    std::cout << "current pos:" << A.position()<< "\n";
    std::cout << A.to_string()<< "\n";
    B.insertBefore(1);
    B.insertBefore(2);
    std::cout << B.to_string() << "\n";
    std::cout << "current pos:" << A.position()<< "\n";
    std::cout << A.length()<< "\n";
    A.eraseAfter();
    std::cout << A.to_string()<< "\n";
    if (A.equals(B))
      return 1;

    B.movePrev();
    B.eraseAfter();
    if (!A.equals(B))
      return 2;

    A.insertAfter(5);
    B.insertAfter(5);
    A.eraseAfter();
    B.eraseAfter();
    if (!A.equals(B))
      return 3;
    return 0;




}
