//Servesh Karnawat
//skarnawa
//pa6
#include "List.h"
#include <stdexcept>
#include <iostream>
#include <cstdlib>
#include <iomanip>
#include "BigInteger.h"
#include <fstream>
#include <string>

int main(int argc, char* argv[]){


    if(argc != 3){
        return EXIT_FAILURE;
    }
    //read the infiles
    std::ifstream inFile(argv[1]);
    std::ofstream outFile(argv[2]);

    std::string line1;
    std::getline(inFile,line1);


    std::string line2;
    std::getline(inFile,line2);


    std::string line3;
    std::getline(inFile,line3);

    //set the big integers

    BigInteger A(line1);
    BigInteger B(line3);

    outFile << A.to_string() << std::endl << std::endl;
    outFile << B.to_string() << std::endl << std::endl;

    BigInteger plus = A+B;
    outFile << plus.to_string() << std::endl << std::endl;

    BigInteger minusAB = A - B;
    outFile << minusAB.to_string() << std::endl << std::endl;

    BigInteger minusAA = A - A;
    outFile << minusAA.to_string() << std::endl << std::endl;

    BigInteger A3 = A *BigInteger(3);
    BigInteger B2 = B *BigInteger(2);

    BigInteger A3subB2 = A3 -B2;

    outFile << A3subB2.to_string() << std::endl << std::endl;

    BigInteger AmultB = A *B;
    outFile << AmultB.to_string() << std::endl << std::endl;

    BigInteger Asq = A *A;
    outFile << Asq.to_string() << std::endl << std::endl;

    BigInteger Bsq = B *B;
    outFile << Bsq.to_string() << std::endl << std::endl;

    BigInteger A4 = Asq*Asq;
    BigInteger A94 = A4*9;

    BigInteger B4 = Bsq* Bsq;
    BigInteger B5 = B4*B;
    BigInteger B165 = B5*16;
    BigInteger big = A94 + B165;
    outFile << big.to_string() << std::endl << std::endl;

    inFile.close();
    outFile.close();
    return 0;


















    



    return 0;
}
