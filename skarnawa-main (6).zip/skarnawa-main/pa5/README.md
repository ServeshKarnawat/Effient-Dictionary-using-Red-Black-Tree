//Servesh Karnawat
//skarnawa
//Pa5

Makefile: creates rules to determine which parts of the program need to be recompiled

List.h: instantiates all the functions for the List ADT in C++

List.cpp: has the actual code to run the functions declared in List.h

ListTest.cpp: Tests my functions made in List.cpp

Shuffle.cpp: computes the amonut of riffle shuffles need to performed on an amount of cards until it is returned to its original state. 