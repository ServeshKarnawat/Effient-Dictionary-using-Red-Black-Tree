//Servesh Karnawat
//skarnawa
//pa3



#include "Graph.h"
#include "List.h"
#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include <stdbool.h>



typedef struct GraphObj{
    List *adj;
    int *color;
    int *parent;
    int *distance;
    int size;
    int source;
    int order;
    int *discover;
    int *finish;
    int time;



} GraphObj;



/*** Constructors-Destructors ***/
Graph newGraph(int n){
    Graph g = malloc(sizeof(GraphObj));
    if(g!=NULL){
        g->adj = malloc(sizeof(List) * (n+1));
        g->color= malloc(sizeof(int)*(n+1));
        g->parent = malloc(sizeof(int)*(n+1));
        g->distance = malloc(sizeof(int)*(n+1));
        g->discover = malloc(sizeof(int)*(n+1));
        g->finish = malloc(sizeof(int)*(n+1));
        g->order = n;
        g->size = 0;
        g->source = NIL;
        g->time =0;



        for(int i = 1; i<=n; i++){
            g->adj[i] = newList();
            g->color[i] = 0;
            g->parent[i] = NIL;
            g->distance[i] = INF;
            g->discover[i] = UNDEF;
            g->finish[i] = UNDEF;
        }

        return g;


    }
    else{
        fprintf(stderr,"could not malloc\n");
        exit(EXIT_FAILURE);
    }
}
void freeGraph(Graph* pG){
    if(pG != NULL && *pG!= NULL){
        for(int i = 1; i < (*pG)->order+1; i++){
            freeList(&((*pG)->adj[i]));
        }
        free((*pG)->adj);
        free((*pG)->color);
        free((*pG)->parent);
        free((*pG)->distance);
        free((*pG)->discover);
        free((*pG)->finish);
        free(*pG);
        *pG = NULL;

    }
}
/*** Access functions ***/
int getOrder(Graph G){
    return G->order;
}

int getSize(Graph G){
    return G->size;
}
int getSource(Graph G){
    return G->source;
}
int getParent(Graph G, int u){
    if(u<1 || u> G->order){
        fprintf(stderr, "invalid index calling getParent()\n");
        return NIL;
    }
    else{
        return G->parent[u];
        exit(EXIT_FAILURE);
    }
}
int getDist(Graph G, int u){
    if(u<1 || u> G->order){
        fprintf(stderr, "invalid index calling getDist()\n");
        return INF;
    }
    else{
        return G->distance[u];
        exit(EXIT_FAILURE);

    }


}
void getPath(List L, Graph G, int u){
    if(u<1 || u> G->order){
        fprintf(stderr,"calling invalid number on getPath()\n");
    }

    if(getSource(G) == NIL){
        fprintf(stderr,"Called getPath() with NIL source\n");
    }
    
    List T = newList();
    int x = u;

    //start at target vertex and follow parents adding them to list
    while(x != NIL){

        prepend(T,x);
        x = G->parent[x];

    } 

    //if last element not source then invalid Path
    if(front(T)!= getSource(G)){
        append(L, NIL);
        freeList(&T);
        return; 

    }

    //copy from T to L 
    moveFront(T);
    for(int i = 0; i < length(T); i++){
        append(L,get(T));
        moveNext(T);
    }

    freeList(&T);
}
/*** Manipulation procedures ***/
void makeNull(Graph G){
	for (int i = 1; i <= G->order; i++){
		clear(G->adj[i]);
		G->color[i] = 0;
		G->parent[i] = NIL;
		G->distance[i] = INF;
        G->discover[i] = UNDEF;
        G->finish[i] = UNDEF;
	}
	G->size = 0;
    G->time = 0;
	G->source = NIL;
}	
void addEdge(Graph G, int u, int v){
    if( u < 1 || u> getOrder(G) || v < 1 || v>getOrder(G)){
        fprintf(stderr, "calling addEdge() on invalild u or v\n");

    }
    else{
        addArc(G,u,v);
        addArc(G,v,u);
        //2 addArcs add 2 size so substract one so only adds one

        G->size--;
    }
}
void addArc(Graph G, int u, int v){
     if(u<1 || u> getOrder(G) || v<1 || v>getOrder(G)){
        fprintf(stderr, "calling addArc on invalid u or v\n");

    }
    else{
        List T = G->adj[u];

        int added = 0;
        bool dup = false;
        int current;
        moveFront(T);
        for(int i = 0; i <= index(T); moveNext(T) ){
            current = get(T);

            if (v< current){
                insertBefore(T, v);
                added = 1;
                break;
            }
            if(v == current){
                dup = true;
            }


        }

        if(added == 0){
            append(T,v);

        }
        if(!dup){
            G->size++;
        }
        
    }



}
void BFS(Graph G, int s){
    for(int x = 0; x<= G->order ; x++){
        G->color[x] = 0;
        G->distance[x] = INF;
        G->parent[x] = NIL;

    }
    G->source = s;
    G->color[s] = 1;
    G->distance[s] = 0;
    G->parent[s] = NIL;
    List Q = newList();
    append(Q, s);
    int current;
    while (length(Q) > 0){
        current = front(Q);

        for(moveFront(G->adj[current]); index(G->adj[current])>=0; moveNext(G->adj[current])){
            int y = get (G->adj[current]);
            if(G->color[y] == 0){
                G->color[y] = 1;
                G->distance[y] = G->distance[current] +1;
                G->parent[y] = current;
                append(Q,y);
            }

        }
        G->color[current] = 1;
        deleteFront(Q);

    }
    freeList(&Q);


}


/*** Other operations ***/
void printGraph(FILE* out, Graph G){
    for(int i = 1; i <= G->order ; i++){
        fprintf(out, "%d: ", i);
        if(length(G->adj[i]) != 0){
            printList(out, G->adj[i]);
        }
        
        fprintf(out, "\n");
    }
}




//pa3 specific functions
int getDiscover(Graph G, int u){
    if(u<1 || u> G->order){
        fprintf(stderr, "calling getDiscover() on invalid index");
        exit(EXIT_FAILURE);
    }
    else{
        return G->discover[u];

    }

}
int getFinish(Graph G, int u){
    if(u<1 || u> G->order){
        fprintf(stderr, "calling getFinish() on invalid index");
        exit(EXIT_FAILURE);
    }
    else{
        return G->finish[u];
    }
}

void Visit(Graph G, int x, List S){
    G->time = (G->time)+1;
    G->discover[x]= G->time;
    G->color[x] = 1;
    moveFront(G->adj[x]);
    for(int i = 0;i< length(G->adj[x]); i++){
        int cur = get(G->adj[x]);

        if(G->color[cur]== 0){
            G->parent[cur] = x;
            Visit(G, cur, S);



        }
        moveNext(G->adj[x]);


    }
    G->color[x] = 2;
    G->time = (G->time)+1;

    G->finish[x] = (G->time);
    //prepend because adding to stack not queue
    prepend(S, x);

    
}


void DFS(Graph G, List S){
    if(length(S) != G->order){
        fprintf(stderr, "DFS with invalid list length");
        exit(EXIT_FAILURE);

    }

    for (int i = 1; i<= G->order; i++){
        G->color[i] = 0;
        G->parent[i] = NIL;
    }
    G->time = 0;
    //traverse the list by traversing copy and saving final changed on S
    List C = copyList(S);
    clear(S);


    moveFront(C);
    for (int i = 1; i<= G->order; i++){
        int current = get(C);
        if(G->color[current] == 0){
            Visit(G, current, S);




            //visit i
            
        }
        moveNext(C);
    }
    freeList(&C);

}


Graph transpose(Graph G){
    Graph T = newGraph(G->order);
    for(int i = 1; i<= G->order; i++){
        
        moveFront(G->adj[i]);
        while(index(G->adj[i]) >= 0){
            addArc(T,get(G->adj[i]),i);
            moveNext(G->adj[i]);

        }
    }

    return T;

}
Graph copyGraph(Graph G){
    Graph C = newGraph(G->order);
    for( int i = 1; i<= G->order; i++){
        moveFront(G->adj[i]);
        for(int j = 0; j<length(G->adj[i]); j++){
            addArc(C, i, get(G->adj[i]));
            moveNext(G->adj[i]);
        }

        C->color[i] = G->color[i];
        C->parent[i] = G->parent[i];
        C-> discover[i] = G->discover[i];
        C->finish[i] = G->finish[i];

    }
    return C;
}
