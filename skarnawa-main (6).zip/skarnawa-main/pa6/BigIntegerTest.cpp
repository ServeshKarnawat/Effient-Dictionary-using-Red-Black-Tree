//Servesh Karnawat
//skarnawa
//pa6

#include<iostream>
#include<string>
#include "BigInteger.h"
#include "List.h"
#include <stdio.h>


int main(){
    

    /*
    BigInteger x= BigInteger("1010083478203002847923049022");

    std::cout << "testing to string: "<<x.to_string() << "\n";


    return 0;
    */
    BigInteger A = BigInteger("111122223333");
    BigInteger B = BigInteger("111122223333");

    // pos + pos = pos
    BigInteger D = BigInteger("12348148518469129628889");
    BigInteger C ;
    // pos * pos = pos
    C = A * B;
    if (C.sign() != 1)
      return 1;



    if (!(C == D))
      return 2;

    std::cout<<"passing1\n";

    // pos * neg = neg
    B.negate();
    D.negate();
    C = A * B;
    if (C.sign() != -1)
      return 3;
    if (!(C == D))
      return 4;
    std::cout<<"passing2\n";

    B.makeZero();
    C = A * B;
    if (C.sign() != 0)
      return 5;
    std::cout<<"passingfinal\n";





    /*
    if (!(C == D))
      return 1;

    // add a positive and a negative integer
    //-> pos + neg = 0
    B = BigInteger("-111122223333");
    C = A + B;

    

    if (C.sign() != 0)
      return 2;

    std::cout << "passed test\n";

    //-> pos + neg > 0
    B = BigInteger("-110122223333");
    D = BigInteger("1000000000");
    C = A + B;
    if (C.sign() != 1)
      return 31;
    std::cout << "passed test1\n";
    if (!(C == D))
      return 32;
    std::cout << "passed test2\n";

    

    //-> pos + neg < 0
    //BigInteger A = BigInteger("+111122223333");
    B = BigInteger("-112122223333");
    D = BigInteger("-1000000000");
    C = A + B;

    if (C.sign() != -1)
      return 41;
    std::cout << "passed test3\n";
    std::cout << "C is : " << C.to_string()<< "\n";
    std::cout <<"D is : " << D.to_string()<< "\n"; 
    if (!(C == D))
      return 42;
    std::cout << "passed test4\n";

    //-> neg + neg = neg
    A = BigInteger("-221211110000");
    D = BigInteger("-333333333333");
    //B = BigInteger("-112122223333");
    C = A + B;

    std::cout << "C signum is"<<C.sign() << "\n";
    std::cout << "D signum is"<<D.sign() << "\n";
    std::cout << "C is :"<< C.to_string() <<"\n";
    std::cout << "D is :"<< D.to_string() <<"\n";
    if (!(C == D))
      return 5;
    std::cout << "passing final test \n";

    return 0;
    */
    
    


}
