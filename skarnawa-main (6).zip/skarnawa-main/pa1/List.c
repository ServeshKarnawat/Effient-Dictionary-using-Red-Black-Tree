//Servesh Karnawat
//skarnawa
//pa1



#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "List.h"
#include<string.h>

//nodes

//bidirectional queue that holds nodes
typedef struct NodeObj* Node;

typedef struct NodeObj{
    int data;
    struct NodeObj *next;
    struct NodeObj *prev;

} NodeObj;

typedef struct ListObj{
    Node head;
    Node tail;
    Node current;
    int length;
    int index;
} ListObj;



// Constructors-Destructors ---------------------------------------------------
List newList(void){
    List L = malloc(sizeof(ListObj));
    L->head = NULL;
    L->tail = NULL;
    L->current = NULL;
    L->length = 0;
    L->index = -1;
    return L;
    } // Creates and returns a new empty List.
void freeList(List* pL){
    if(pL != NULL && *pL != NULL){
        clear(*pL);
        free(*pL);
        *pL= NULL;
    }
    } // Frees all heap memory associated with *pL, and sets
 // *pL to NULL.
 // Access functions -----------------------------------------------------------
int length(List L){
    return L->length;
    } // Returns the number of elements in L.
int index(List L){
    
    return L->index;

    } // Returns index of cursor element if defined, -1 otherwise.
int front(List L){
    if(L->length > 0 ){
        return (L->head)->data;

    }
    else{
        fprintf(stderr, "called front() on empty list");
        return -1;
    }

} // Returns front element of L. Pre: length()>0
int back(List L){
    if(L->length > 0 ){
        return (L->tail)->data;

    }
    else{
        fprintf(stderr, "called back() on empty list");
        return -1;
    }
    } // Returns back element of L. Pre: length()>0
int get(List L){
    if(L->length >0 && index >=0){
        return (L->current)->data;
    }
    else{
        fprintf(stderr,"called get() on undefined element");
        return -1;
    }

} // Returns cursor element of L. Pre: length()>0, index()>=0
bool equals(List A, List B){
    //check if theyre even the same length
    if(A->length != B->length){
        return false;

    }
    //go through each value now

    //set up temp variables to save where before this

    Node tempA = A->current;
    Node tempB = B->current;

    //set current to front to start traversal
    A->current= A->head;
    B->current= B->head;
    for (int i=0; i< A->length ; i++){
        if(A->current->data != B->current->data){
            A->current = tempA;
            B->current = tempB;
            return false;

        }
        A->current = A->current->next;
        B->current = B->current->next;



    }


    A->current = tempA;
    B->current = tempB;
    return true;
} // Returns true iff Lists A and B contain the same
 // sequence of elements, returns false otherwise.



// Manipulation procedures ----------------------------------------------------
void clear(List L){
    L->current = L->head;
    while(L->length >0){
        deleteFront(L);
    }
    L->current = NULL;
    L->head = NULL;
    L->tail = NULL;
    L->index=-1;
    L->length = 0;

} // Resets L to its original empty state.
void set(List L, int x){
    if(length(L) > 0 && index(L)>=0){
        (L->current)->data = x;

    }
    else{
        fprintf(stderr, "called set() and called on an invalid position");
    }

} // Overwrites the cursor element’s data with x.
 // Pre: length()>0, index()>=0
void moveFront(List L){
    if(L->length != 0){
        L->current = L->head;
        L->index=0;

    }
} // If L is non-empty, sets cursor under the front element,
 // otherwise does nothing.
void moveBack(List L){
        if(L->length != 0){
        L->current = L->tail;
        L->index=L->length -1;
        
    }
} // If L is non-empty, sets cursor under the back element,
 // otherwise does nothing.
void movePrev(List L){
    //exists and is not first means there is at least one before it
    if(L->current!= NULL) {
        //exists and at the front
        if (L->index == 0){
            L->current = NULL;
            L->index = -1;

        }
        //exists and not at front
        else{
            L->current = (L->current)->prev;
            L->index--;
        }
        
    }
     


} // If cursor is defined and not at front, move cursor one
 // step toward the front of L; if cursor is defined and at
 // front, cursor becomes undefined; if cursor is undefined
 // do nothing
void moveNext(List L){
    if(L->current!= NULL) {
        //exists and at the back
        if (L->index == (L->length) -1){
            L->current = NULL;
            L->index = -1;

        }
        //exists and not at back
        else{
            L->current = (L->current)->next;
            L->index++;
        }
        
    }
} // If cursor is defined and not at back, move cursor one
 // step toward the back of L; if cursor is defined and at
 // back, cursor becomes undefined; if cursor is undefined
 // do nothing
 void prepend(List L, int x){
    Node n = malloc(sizeof(NodeObj));
    //if this is an empty list
    n->data = x;
    n->prev = NULL;
    if(L->length == 0){
        n->next = NULL;
        L->tail = n;
        //i will add to length regardless so set length to 0 so that its not -1 anymore and then 0+1 will be 1
        L->length = 0;
    }
    //list is not empty so there is something in front of it 
    else{
        n->next = L->head;
        //the item that used to be first set the new thing as its prev
        (L->head)->prev = n;
        if(L->index >=0){
            L->index++;
        }
    }
    L->length++;
    L->head = n;
 } // Insert new element into L. If L is non-empty,
 // insertion takes place before front element.
void append(List L, int x){
    Node n = malloc(sizeof(NodeObj));
    
    n->data = x;
    n->next = NULL;
    //if this is an empty list
    if(L->length == 0){
        n->prev = NULL;
        L->head = n;
        
        //i will add to length regardless so set length to 0 so that its not -1 anymore and then 0+1 will be 1
        L->length = 0;
    }
    //list is not empty so there is something in back of it 
    else{
        n->prev = L->tail;
        //the item that used to be last set the new thing as its next
        (L->tail)->next = n;
    }
    L->length++;
    L->tail = n;

} // Insert new element into L. If L is non-empty,
 // insertion takes place after back element.
void insertBefore(List L, int x){
    //check to make sure cursor even real:
    if(L->current != NULL){
        //cursor exists implies there is at least one element so no need to worry new list start or whats next
        Node n = malloc(sizeof(NodeObj));
        n->data = x;
        n->next = L->current;
        //if cursor is at begining
        if(L->index ==0){
            n->prev = NULL;
            L->head = n;
            //if there is a number after then increase index
            



        }
        //cursor in middle
        else{
            n->prev = (L->current)->prev;
            L->current->prev->next= n;


        }
        (L->current)->prev = n;
        L->length++;
        L->index++;



    }
} // Insert new element before cursor.
 // Pre: length()>0, index()>=0
void insertAfter(List L, int x){
    //check to make sure cursor even real:
    if(L->current != NULL){
        //cursor exists implies there is at least one element so no need to worry new list start or whats next
        Node n = malloc(sizeof(NodeObj));
        n->data = x;
        n->prev = L->current;
        //if cursor is at ending
        if(L->index == (L->length )-1){
            n->next = NULL;
            L->tail = n;



        }
        //cursor in middle
        else{
            n->next = (L->current)->next;
            L->current->next->prev= n;
            


        }
        (L->current)->next = n;
        L->length++;


    }
} // Insert new element after cursor.
 // Pre: length()>0, index()>=0
void deleteFront(List L){
    //make sure the list isn't empty
    if(L->length >0){
        Node oldhead = L->head;
        //if only one item
        if(L->index<0){
            L->index = 0;
        }
        if(L->length == 1){
            L->head = NULL;
            L->tail = NULL;
            L->current = NULL;
            //index 0 because end will default substract one so it will be -1 after
            L->index = 0;

        }
        //make sure index is right

        
        

        
        //if multiple items then something need to move up and be new head
        else{
            
            L->head = L->head->next;
            L->head->prev = NULL;



        }

        //also check to make sure cursor isn't the one at front being removed
        if(L->index == 0){
            L->current = NULL;
            L->index = 0;

        }
        L->index--;
        L->length--;
        free(oldhead);
    }

    
} // Delete the front element. Pre: length()>0
void deleteBack(List L){
    //make sure the list isn't empty
    if(L->length >0){
        Node oldtail = L->tail;
        //if only one item
        if(L->index<0){
            L->index = -1;
        }
        if(L->length == 1){
            L->head = NULL;
            L->tail = NULL;
            L->current = NULL;
            //index 0 because end will default substract one so it will be -1 after
            L->index = -1;

        }

        
        
        

        
        //if multiple items then something need to move up and be new tail
        else{
            
            L->tail = L->tail->prev;
            L->tail->next = NULL;



        }

        //also check to make sure cursor isn't the one at front being removed
        if(L->index == (L->length)-1){
            L->current = NULL;
            L->index = -1;

        }
        L->length--;
        free(oldtail);
}
} // Delete the back element. Pre: length()>0

void delete(List L){

    if(L->length > 0 && L->index>=0  ){
        //only item in the list
        if(L->length == 1){
            L->head = NULL;
            L->tail = NULL;
            //index 0 because end will default substract one so it will be -1 after
            L->index = -1;
            free(L->current);
            L->length--;
            L->current = NULL;
        }
        //delete regularly now
        else{

            //if it is at the front
            if(L->index == 0){
                deleteFront(L);


            }
            //at back
            else if(L->index == (L->length)-1 ){
                deleteBack(L);
            }
            //in middle
            else{
                L->current->prev->next = L->current->next;
                L->current->next->prev = L->current->prev;
                free(L->current);
                L->length--;
                L->index = -1;
                L->current = NULL;

                
            }
        }



    }
    else{
        fprintf(stderr, "deleting not possible");
    }


    
} // Delete cursor element, making cursor undefined.
 // Pre: length()>0, index()>=0
// Other operations -----------------------------------------------------------
void printList(FILE* out, List L){
    if(L->length >=1){
    //need a temporary start before I traverse
    Node temp = L->current;
    L->current = L->head;
    for (int i = 0; i< L->length; i++){
        fprintf(out, "%d ", L->current->data );
        L->current = L->current->next;

    }
    printf("\n");
    L->current = temp;
    }
} // Prints to the file pointed to by out, a
 // string representation of L consisting
// of a space separated sequence of integers,
// with front on left.
List copyList(List L){
    List newL = newList();
    Node temp = L->current;
    L->current = L->head;
    for (int i = 0; i< L->length; i++){
        append(newL, L->current->data);
        L->current = L->current->next;

    }
    L->current = temp;
    return newL;
    }

 // Returns a new List representing the same integer
 // sequence as L. The cursor in the new list is undefined,
// regardless of the state of the cursor in L. The state
// of L is unchanged.