//Servesh Karnawat
//skarnawa
//pa6

//-----------------------------------------------------------------------------
// BigInteger.h
// Header file for the BigInteger ADT
//-----------------------------------------------------------------------------
#include <iostream>
#include <string>
#include"List.h"
#include "BigInteger.h"
#include <typeinfo>



const int power = 9;
const ListElement base = 1000000000;

// Exported type  -------------------------------------------------------------



// BigInteger Fields 


// BigInteger()
// Constructor that creates a new BigInteger in the zero state: 
// signum=0, digits=().
BigInteger::BigInteger(){
    signum = 0;    // +1 (positive), -1 (negative), 0 (zero)
    // List of digits in this BigInteger
}

// Class Constructors & Destructors ----------------------------------------


void normalize(List &L){
    long carry = 0;
    L.moveBack();
    for(int i = 0; i < L.length(); i++){
        long digit = L.movePrev();
        digit = digit +carry;
        carry = 0;
        if(digit < 0){
            while(digit < 0){
                digit = digit+base;
                carry = carry -1;
                
            }
            L.eraseAfter();
            L.insertAfter(digit);
        }
        else if(digit> base){
            long subcarry = digit/base;
            carry = carry + subcarry;
            digit = digit- (base*subcarry);
            L.eraseAfter();
            L.insertAfter(digit);

        }
        else{
            L.eraseAfter();
            L.insertAfter(digit);
        }

    }
    //if last digit is negative or too positive
    if(carry <0 ){
        //negate everything then recall normalize
        L.moveFront();
        for(int i = 0; i < L.length(); i++){
            long swap = L.moveNext();
            L.eraseBefore();
            L.insertBefore(swap*-1); 
        }
        long carry = 0;
        L.moveBack();
        for(int i = 0; i < L.length(); i++){
            long digit = L.movePrev();
            digit = digit +carry;
            carry = 0;
            if(digit < 0){
                while(digit < 0){
                    digit = digit+base;
                    carry = carry -1;
                    
                }
                L.eraseAfter();
                L.insertAfter(digit);
            }
            else if(digit> base){
                long subcarry = digit/base;
                carry = carry + subcarry;
                digit = digit- (base*subcarry);
                L.eraseAfter();
                L.insertAfter(digit);

            }
            else{
                L.eraseAfter();
                L.insertAfter(digit);
            }

        }

        
    }
    //if carry resulted in too big
    if(carry != 0){
        L.moveFront();
        L.insertAfter(carry);

    }
    //getting rid of 0s from start to end
    L.moveFront();

    //length adjusts and can keep extra 0 so need length to be regular
    int l = L.length();
    for (int i = 0; i < l; i++){
        long current = L.moveNext();
        
        if(current == 0){
            L.eraseBefore();

        }
        else{

            break;
        }
    }

}
// BigInteger()
// Constructor that creates a new BigInteger from the long value x.
BigInteger::BigInteger(long x){

    if(x==0){
        signum = 0;
        return;
    }
    if(x>0){
        signum =1;

    }
    if(x<0){
        signum = -1;
        x = 0- x;

    }


    while (x>1){        
        digits.insertAfter(x % base);
        x = x/base;
    }
    normalize(digits);


}



// BigInteger()
// Constructor that creates a new BigInteger from the string s.
// Pre: s is a non-empty string consisting of (at least one) base 10 digit
// {0,1,2,3,4,5,6,7,8,9}, and an optional sign {+,-} prefix.
BigInteger::BigInteger(std::string s){

    if(s.length()< 1){
        throw std::invalid_argument("BigInteger: Constructor: empty string\n");
    
    }
    if(s[0] == '-'){
        signum = -1;
        //get rid of negative for calculations
        s.erase(0,1);

    }
    else if (s[0] == '+'){
        signum = 1;
        s.erase(0,1);
    }
    else{
        signum = 1;
    }
    //whole thing is number

    int numreached = 0;
    for (int i = 0; i < int(s.length()); i++ ){
        
        if(!(isdigit(s[i]))){
            throw std::invalid_argument("BigInteger: Constructor: non-numeric string");

        }
        if(s[i] !=0){
            numreached =1;
        }
        if(s[i]==0&& numreached ==0){
            s.erase(0,1);
        }
    }
    //break into the subparts

    
    int stop;
    int start = s.length();
    //std::cout << "about to go into loop \n";
    while(s.length() >0){

        stop = s.length()-power;

        if(stop >=0){
            stop = stop;
        }
        else{
            stop = 0;            
        }
        
        int end = start;
        start = std::max(0,start - power);
        std::string chunk = s.substr(start, end -start);
        long val = atol(chunk.c_str());
        //std::cout << "before turning it to numerb: "<<chunk ;
        //std:: cout<< "after: " << val ;
        

        digits.insertAfter(val);

        //digits.insertAfter(atol((s.substr(stop, s.length())).c_str()));
        s.erase(stop,s.length());

        


        
    }
    normalize(digits);
}




// BigInteger()
// Constructor that creates a copy of N.
BigInteger::BigInteger(const BigInteger& N){
    List l = N.digits;
    signum = N.signum;
    
    l.moveFront();
    for (int i = 0; i<l.length(); i++){
        digits.insertBefore(l.moveNext());
    }

}

// Optional Destuctor
// ~BigInteger()
// ~BigInteger();


// Access functions --------------------------------------------------------

// sign()
// Returns -1, 1 or 0 according to whether this BigInteger is positive, 
// negative or 0, respectively.
int BigInteger::sign() const{
    return signum;
}

// compare()
// Returns -1, 1 or 0 according to whether this BigInteger is less than N,
// greater than N or equal to N, respectively.
int BigInteger::compare(const BigInteger& N) const{
    //check if negative positive first
    if(signum < N.signum){
        return -1;
    }
    else if (signum > N.signum){
        return 1;

    }
    //same signum check the lengths
    else{

        //if N is longer than current depends on negative or positive
        if(digits.length() < N.digits.length()){
            //if N longer and postive N bigger current is smaller
            if(signum == 1){
                return -1;
            }
            //if N is longer and negative then current is bigger
            if(signum == -1){
                return 1;
            }
        }
        //if N is shorter than current then depends on the sign again

        if(digits.length() > N.digits.length()){
            //if N is shorter and positive current is greater
            if(signum == 1){
                return 1;
            }
            //if n is short and negative then N is bigger
            if(signum == -1){
                return -1;
            }
        }

        //same sign and same length
        else{
            //go through every value and compare
            List current = digits;
            List LN = N.digits;
            current.moveFront();
            LN.moveFront();

            for(int i = 0; i < current.length(); i++){
                long cVal = current.moveNext();
                long LNVal = LN.moveNext();
                if(cVal > LNVal){
         


                    return 1;
                }
                else if(LNVal > cVal){
               
                    return -1;
                }
            }
           
            //same sign same length same values means it is the same
            return 0;

        }
        return 0;

    }
    return 0;


}


// Manipulation procedures -------------------------------------------------

//normalize





// makeZero()
// Re-sets this BigInteger to the zero state.
void BigInteger::makeZero(){
    signum = 0;
    digits.clear();

}

// negate()
// If this BigInteger is zero, does nothing, otherwise reverses the sign of 
// this BigInteger positive <--> negative. 
void BigInteger::negate(){
    if(signum == 0){

    }
    else{
        signum = signum * -1;
    }

}


// BigInteger Arithmetic operations ----------------------------------------

// add()
// Returns a BigInteger representing the sum of this and N.
BigInteger BigInteger::add(const BigInteger& N) const{
    BigInteger summed;
    //if adding with 0s
    if(N.signum == 0 && signum == 0){
        summed = N.signum;
        return summed;
    }
    if(N.signum == 0 && signum != 0){
        summed = *this;
        return summed;

    }
    if(N.signum != 0 && signum == 0){
        summed = N.signum;
        return summed;
    }
    //not adding with 0s need regular number addition
    else{
        List A = digits;
        List B = N.digits;

        if(signum == -1){
            A.moveFront();
            for(int i = 0; i < A.length(); i++){
                long swap = A.moveNext();
                A.eraseBefore();
                A.insertBefore(swap*-1); 
            }
        
        }

        A.moveBack();
        B.moveBack();
        int len;
        if(A.length() > B.length()){
            len = A.length();
        }
        else{
            len = B.length();
        }

        for(int i = 0; i < len; i++){
            long total;
            //to make sure when some are negative
            if(A.position() == 0){
                total = N.signum * B.movePrev();

            }
            else if(B.position() == 0){
                total = A.movePrev();
                
            }
            else{
                total = A.movePrev()+(N.signum * B.movePrev());
                //std::cout << "total: "<< total << "\n";
                //std::cout << "\n inside C\n";
            }
            summed.digits.insertAfter(total);
        }
        

        normalize(summed.digits);
        //std::cout<< "summed.didtes after the normalize: "<< (summed.digits).to_string()<< "\n";

        if(summed.digits.length() == 0){
            summed.signum = 0;
            return summed;
        }

        summed.digits.moveFront();
        if(summed.digits.peekNext() == -1){
            summed.signum = -1;
            summed.digits.eraseAfter();
            
        }
        else{
            summed.signum = 1;
        }

        return summed;
        




    }
    return summed;
}

// sub()
// Returns a BigInteger representing the difference of this and N.
BigInteger BigInteger::sub(const BigInteger& N) const{
    BigInteger subbed;
    //if adding with 0s
    if(N.signum == 0 && signum == 0){
        subbed = N.signum;
        return subbed;
    }
    if(N.signum == 0 && signum != 0){
        subbed = *this;
        return subbed;

    }
    if(N.signum != 0 && signum == 0){
        subbed = N.signum;
        subbed.negate();
        return subbed;
    }
    //not adding with 0s need regular number addition
    else{
        List A = digits;
        List B = N.digits;

        if(signum == -1){
            A.moveFront();
            for(int i = 0; i < A.length(); i++){
                long swap = A.moveNext();
                A.eraseBefore();
                A.insertBefore(swap*-1); 
            }
        
        }
        B.moveFront();
        for(int i = 0; i < B.length(); i++){
            long swap = B.moveNext();
            B.eraseBefore();
            B.insertBefore(swap*-1); 
        }

        A.moveBack();
        B.moveBack();
        int len;
        if(A.length() > B.length()){
            len = A.length();
        }
        else{
            len = B.length();
        }

        for(int i = 0; i < len; i++){
            long total;
            //to make sure when some are negative
            if(A.position() == 0){
                total = N.signum * B.movePrev();

            }
            else if(B.position() == 0){
                total = A.movePrev();
                
            }
            else{
                total = A.movePrev()+(N.signum * B.movePrev());
                //std::cout << "total: "<< total << "\n";
                //std::cout << "\n inside C\n";
            }
            subbed.digits.insertAfter(total);
        }
        

        normalize(subbed.digits);
        //std::cout<< "summed.didtes after the normalize: "<< (summed.digits).to_string()<< "\n";

        if(subbed.digits.length() == 0){
            subbed.signum = 0;
            return subbed;
        }

        subbed.digits.moveFront();
        if(subbed.digits.peekNext() == -1){
            subbed.signum = -1;
            subbed.digits.eraseAfter();
            
        }
        else{
            subbed.signum = 1;
        }

        return subbed;
        




    }
    return subbed;
}
void scalarMult(List &L, ListElement factor){
    L.moveFront();
    for (int i = 0; i < L.length() ; i++){
        
        long val = L.moveNext() * factor;
        L.eraseBefore();
        L.insertBefore(val);

    }
}
void shift(List &L, int a){
    L.moveBack();
    for (int i = 0; i < a; i++){
        L.insertAfter(0);
    }
}

// mult()
// Returns a BigInteger representing the product of this and N. 
BigInteger BigInteger::mult(const BigInteger& N) const{
    List B = N.digits;
    BigInteger total = BigInteger("0");
    BigInteger temp = BigInteger();
    if(signum ==0 || N.signum == 0){
        total.signum = 0;
        return total;
    }
    B.moveBack();
    for(int i = 0; i< B.length() ; i++){
        List A = digits;
        
        long current = B.movePrev();
        shift(A,i);
        scalarMult(A,current);
   
        normalize(A);
               temp.digits = A;
        temp.signum = 1;
        //std::cout << "temp is "<< temp.digits.to_string() << "\n";

        total = total+temp;
        normalize(total.digits);
    }
    if(total.digits.length()== 0 || N.signum == 0 || signum ==0){
        total.signum = 0;
    }
    if(signum == N.signum){
        total.signum = 1;
    }
    else{
        total.signum = -1;
    }
    return total;
  
    
}


// Other Functions ---------------------------------------------------------

// to_string()
// Returns a string representation of this BigInteger consisting of its
// base 10 digits. If this BigInteger is negative, the returned string 
// will begin with a negative sign '-'. If this BigInteger is zero, the
// returned string will consist of the character '0' only.


std::string BigInteger::to_string(){
    //digits.moveFront();
    //std::cout << "the digits are of type: " << typeid(digits.moveNext()).name() << "\n";
    std::string num = "";
    if(signum == 0){
        return "0";
    }
    else if(signum == -1){
        num = "-";
    };

    
    digits.moveFront();
    for (int i = 0; i< digits.length(); i++){
        std::string segment = std::to_string(digits.moveNext());
        if(i == 0){
            num = num + segment;
        }
        else{
            num = num + ( std::string (power- segment.length(),'0') + segment);
        }

    }
    return num; 


}


// Overriden Operators -----------------------------------------------------

// operator<<()
// Inserts string representation of N into stream.
std::ostream& operator<<( std::ostream& stream, BigInteger N ){
    return stream << N.to_string();
}

// operator==()
// Returns true if and only if A equals B. 
bool operator==( const BigInteger& A, const BigInteger& B ){
    return A.compare(B) == 0;
}

// operator<()
// Returns true if and only if A is less than B. 
bool operator<( const BigInteger& A, const BigInteger& B ){
    return A.compare(B) == -1;
}

// operator<=()
// Returns true if and only if A is less than or equal to B. 
bool operator<=( const BigInteger& A, const BigInteger& B ){
    return A.compare(B) != 1;
}

// operator>()
// Returns true if and only if A is greater than B. 
bool operator>( const BigInteger& A, const BigInteger& B ){
    return A.compare(B) == 1;
}

// operator>=()
// Returns true if and only if A is greater than or equal to B. 
bool operator>=( const BigInteger& A, const BigInteger& B ){
    return A.compare(B) != -1;
}

// operator+()
// Returns the sum A+B. 
BigInteger operator+( const BigInteger& A, const BigInteger& B ){
    return (A.add(B));
}

// operator+=()
// Overwrites A with the sum A+B. 
BigInteger operator+=( BigInteger& A, const BigInteger& B ){
    A = A.add(B);
    return A;
}

// operator-()
// Returns the difference A-B. 
BigInteger operator-( const BigInteger& A, const BigInteger& B ){
    return (A.sub(B));

}

// operator-=()
// Overwrites A with the difference A-B. 
BigInteger operator-=( BigInteger& A, const BigInteger& B ){
    A = A.sub(B);
    return A;
}

// operator*()
// Returns the product A*B. 
BigInteger operator*( const BigInteger& A, const BigInteger& B ){
    return (A.mult(B));
}

// operator*=()
// Overwrites A with the product A*B. 
BigInteger operator*=( BigInteger& A, const BigInteger& B ){
    A = A.mult(B);
    return A;
}


