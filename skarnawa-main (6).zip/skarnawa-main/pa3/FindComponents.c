//Servesh Karnawat
//skarnawa
//pa3
#include "Graph.h"
#include "List.h"



int main (int argc,char* argv[]){
    FILE *inFile = fopen(argv[1], "r");
    if (inFile == NULL){
        fprintf(stderr, "you entered a null file");
        return -1;
    }

    FILE *outFile = fopen(argv[2], "w");


    //read vertices
    int n;
    fscanf(inFile, "%d", &n);
    //create graph
    Graph G = newGraph(n);
    List S = newList();
    //populate list
    for (int i = 1; i<=n ; i++){
        append(S, i);
    }



    //read the file and make the graph
    int u;
    int v;

    while(fscanf(inFile, "%d %d", &u, &v) == 2){
        if(u == 0 && v == 0  ){
            break;
        }
        addArc(G, u, v);
    }


    //find strongly connected components

    DFS(G, S);
    Graph T = transpose(G);
    DFS(T,S);

    int strongamt = 0;
    int current;

    moveFront(S);
    while (index(S) >=0){
        current = get(S);
        if(getParent(T,current) == NIL){
            strongamt++;

        }
        moveNext(S);
    }
    fprintf(outFile, "Adjacency list representation of G:\n");
    printGraph(outFile, G);
    fprintf(outFile,"\n\n");
    fprintf(outFile,"G contains %d strongly connected components:\n",strongamt);


    
    



    
    moveBack(S);
    int i = 1;
    List comps = newList();
    while(index(S) >=0){
        current = get(S);
        
        while(index(S)>=0 && getParent(T,current) != NIL){
            prepend(comps, get(S));
            movePrev(S);
            current = get(S);
        }

        prepend(comps, get(S));
        fprintf(outFile,"Component %d:", i);
        printList(outFile, comps);
        fprintf(outFile,"\n");
        clear(comps);
        movePrev(S);
        i++;
    }


    freeList(&comps);
    freeList(&S);
    freeGraph(&T);
    freeGraph(&G);




    


    








    
    return 0;




}