//Servesh Karnawat
//skarnawa
//pa1




#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "List.h"

int main(int argc, char* argv[]){
    if(argc != 3){
        fprintf(stderr, "incorrect format of running the file. it should be : Lex <input file> <output file>");
    }


    FILE *inFile = fopen(argv[1], "r");
    if (inFile == NULL){
        fprintf(stderr, "you entered a null file");
        return -1;


    }

    FILE *outFile = fopen(argv[2], "w");
    //start counting the lines

    int lineamt = 0;
    char buffer [200];
    //fgets returns NULL when it reaches EOF
    while (fgets(buffer, sizeof(buffer), inFile) != NULL ){
        
        //get rid of \n new line
        if(buffer[(strlen(buffer))-1] == '\n'){
            buffer[(strlen(buffer)) -1] = '\0';
        }
        lineamt++;

    }

    //reset file pointer to beggining so I can re-read file for next part
    rewind(inFile);

    //save the numbers in an array 
    //allocate memory
    char **lines = calloc (lineamt, sizeof(char*));
    for (int i = 0; i<lineamt; i++){
        //read the information from the input file
        fgets(buffer, sizeof(buffer), inFile);
        if(buffer[(strlen(buffer))-1] == '\n'){
            buffer[(strlen(buffer)) -1] = '\0';
        }
        //set buffer in the allocated memory
        //add one to strlenbuffer for ending command
        lines[i] = malloc((strlen(buffer)) +1);
        if (lines[i] != NULL){
            strcpy(lines[i], buffer);
        }
        else{
            fprintf(stderr,"setting data failed");

        }

    }
    fclose(inFile);

    List myList = newList();


    //insertion sort with the ADT
    for(int i = 0; i < lineamt; i++){
        moveFront(myList);

        while (index(myList) >= 0 && strcmp(lines[i], lines[ get(myList)])>0){
            moveNext(myList);
        }
        

        if (index(myList) >= 0){
            insertBefore(myList, i);
        }
        else{
            append(myList,i);
        }
    }

 
    //printing the new sorted items
    moveFront(myList);

    //repeat until every item stated and index = -1 for out of list
    for (int i =0; index(myList) >=0; i++){
        printf(lines[get(myList)]);
        fprintf(outFile, "%s\n", lines[get(myList)]);

        moveNext(myList);
    }
    



    //printList(outFile, myList);
    fclose(outFile);
    


    //free the lines
    for (int i = 0; i<lineamt ; i++){
        free(lines[i]);

    }

    free(lines);

    

    freeList(&myList);
    return 0;
}