//Servesh Karnawat
//skarnawa
//pa7

Makefile: creates rules to determine which parts of the program need to be compiled

Dictionary.h: instatiates the functions to be used in Dictionary.cpp

Dictionary.cpp: creates the actual definitions of the functions made in Dictionary.h

DictionaryTest.cpp: Tests the functions made in Dictionary.cpp

Order.cpp: client for this project that uses functions from Dictionary.h