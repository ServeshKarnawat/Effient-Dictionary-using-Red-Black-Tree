//Servesh Karnawat
//skarnawa
//pa2


#include "Graph.h"
#include "List.h"
#include<stdio.h>
#include<stdlib.h>
#include<assert.h>
#include <stdbool.h>



typedef struct GraphObj{
    List *adj;
    int *color;
    int *parent;
    int *distance;
    int size;
    int source;
    int order;



} GraphObj;



/*** Constructors-Destructors ***/
Graph newGraph(int n){
    Graph g = malloc(sizeof(GraphObj));
    if(g!=NULL){
        g->adj = malloc(sizeof(List) * (n+1));
        g->color= malloc(sizeof(int)*(n+1));
        g->parent = malloc(sizeof(int)*(n+1));
        g->distance = malloc(sizeof(int)*(n+1));
        g->order = n;
        g->size = 0;
        g->source = NIL;


        for(int i = 1; i<=n; i++){
            g->adj[i] = newList();
            g->color[i] = 0;
            g->parent[i] = NIL;
            g->distance[i] = INF;
        }

        return g;


    }
    else{
        fprintf(stderr,"could not malloc\n");
        exit(EXIT_FAILURE);
    }
}
void freeGraph(Graph* pG){
    if(pG != NULL && *pG!= NULL){
        for(int i = 1; i < (*pG)->order+1; i++){
            freeList(&((*pG)->adj[i]));
        }
        free((*pG)->adj);
        free((*pG)->color);
        free((*pG)->parent);
        free((*pG)->distance);
        free(*pG);
        *pG = NULL;

    }
}
/*** Access functions ***/
int getOrder(Graph G){
    return G->order;
}

int getSize(Graph G){
    return G->size;
}
int getSource(Graph G){
    return G->source;
}
int getParent(Graph G, int u){
    if(u<1 || u> G->order){
        fprintf(stderr, "invalid index calling getParent()\n");
        return NIL;
    }
    else{
        return G->parent[u];
        exit(EXIT_FAILURE);
    }
}
int getDist(Graph G, int u){
    if(u<1 || u> G->order){
        fprintf(stderr, "invalid index calling getDist()\n");
        return INF;
    }
    else{
        return G->distance[u];
        exit(EXIT_FAILURE);

    }


}
void getPath(List L, Graph G, int u){
    if(u<1 || u> G->order){
        fprintf(stderr,"calling invalid number on getPath()\n");
    }

    if(getSource(G) == NIL){
        fprintf(stderr,"Called getPath() with NIL source\n");
    }
    
    List T = newList();
    int x = u;

    //start at target vertex and follow parents adding them to list
    while(x != NIL){

        prepend(T,x);
        x = G->parent[x];

    } 

    //if last element not source then invalid Path
    if(front(T)!= getSource(G)){
        append(L, NIL);
        freeList(&T);
        return; 

    }

    //copy from T to L 
    moveFront(T);
    for(int i = 0; i < length(T); i++){
        append(L,get(T));
        moveNext(T);
    }

    freeList(&T);
}
/*** Manipulation procedures ***/
void makeNull(Graph G){
	for (int i = 1; i <= G->order; i++){
		clear(G->adj[i]);
		G->color[i] = 0;
		G->parent[i] = NIL;
		G->distance[i] = INF;
	}
	G->size = 0;
	G->source = NIL;
}	
void addEdge(Graph G, int u, int v){
    if( u < 1 || u> getOrder(G) || v < 1 || v>getOrder(G)){
        fprintf(stderr, "calling addEdge() on invalild u or v\n");

    }
    else{
        addArc(G,u,v);
        addArc(G,v,u);
        //2 addArcs add 2 size so substract one so only adds one

        G->size--;
    }
}
void addArc(Graph G, int u, int v){
    if(u<1 || u> getOrder(G) || v<1 || v>getOrder(G)){
        fprintf(stderr, "calling addArc on invalid u or v\n");

    }
    else{
        List T = G->adj[u];

        int added = 0;
        int current;
        moveFront(T);
        for(int i = 0; i <= index(T); moveNext(T) ){
            current = get(T);

            if (v< current){
                insertBefore(T, v);
                added = 1;
                break;
            }


        }

        if(added == 0){
            append(T,v);

        }

        G->size++;
        
    }

}
void BFS(Graph G, int s){
    for(int x = 0; x<= G->order ; x++){
        G->color[x] = 0;
        G->distance[x] = INF;
        G->parent[x] = NIL;

    }
    G->source = s;
    G->color[s] = 1;
    G->distance[s] = 0;
    G->parent[s] = NIL;
    List Q = newList();
    append(Q, s);
    int current;
    while (length(Q) > 0){
        current = front(Q);

        for(moveFront(G->adj[current]); index(G->adj[current])>=0; moveNext(G->adj[current])){
            int y = get (G->adj[current]);
            if(G->color[y] == 0){
                G->color[y] = 1;
                G->distance[y] = G->distance[current] +1;
                G->parent[y] = current;
                append(Q,y);
            }

        }
        G->color[current] = 1;
        deleteFront(Q);

    }
    freeList(&Q);


}


/*** Other operations ***/
void printGraph(FILE* out, Graph G){
    for(int i = 1; i <= G->order ; i++){
        fprintf(out, "%d: ", i);
        if(length(G->adj[i]) != 0){
            printList(out, G->adj[i]);
        }
        
        fprintf(out, "\n");
    }
}
