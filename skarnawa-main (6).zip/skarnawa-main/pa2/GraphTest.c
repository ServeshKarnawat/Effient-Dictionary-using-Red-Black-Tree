//Servesh Karnawat
//skarnawa
//pa2

#include "Graph.h"


int main(){

    Graph G= newGraph(5);
    List l = newList();

    


    
    append(l,112);
    moveFront(l);
    printList(stdout, l);
    printf("%d\n", length(l));
    printf("%d\n", index(l));
    printf("are we okay?\n");
    delete(l);
    printf("now?\n");

    printf("%d\n", length(l));
    printf("%d\n", index(l));



    printList(stdout, l);

    printf("now1?\n");
    delete(l);
    printf("now2?\n");
    append (l, 10);
    printf("now3?\n");



    printf("This is getOrder %d\n", getOrder(G));
    printf("This is getSize %d\n", getSize(G));
    printf("This is getSource %d\n", getSource(G));
    printf("The parent is %d\n", getParent(G,2));
    printf("calling getparent on bad call %d\n", getParent(G,10));
    printf("Calling getDist() %d\n", getDist(G,1));
    printf("Calling getDist() bad call%d\n", getDist(G,10));
    printf("Calling getpath() \n");
    getPath(l, G,10);

    printf("Calling makeNull() \n");
    makeNull(G);
    printf("adding a bunch of random edges\n");
    addEdge(G, 1, 5);
    addEdge(G, 1, 3);
    addEdge(G, 3, 2);
    addEdge(G, 5, 4);
    addEdge(G, 2, 4);
    printGraph(stdout, G);

    printf("This is getOrder %d\n", getOrder(G));
    printf("This is getSize %d\n", getSize(G));
    printf("This is getSource %d\n", getSource(G));
    printf("The parent is %d\n", getParent(G,2));
    printf("calling getparent on bad call %d\n", getParent(G,10));
    printf("Calling getDist() %d\n", getDist(G,1));
    printf("Calling getDist() bad call%d\n", getDist(G,10));
    printf("Calling getpath() \n");

    BFS(G,4);
    
    printGraph(stdout, G);

    printf("This is getOrder %d\n", getOrder(G));
    printf("This is getSize %d\n", getSize(G));
    printf("This is getSource %d\n", getSource(G));
    printf("The parent is %d\n", getParent(G,2));
    printf("calling getparent on bad call %d\n", getParent(G,10));
    printf("Calling getDist() %d\n", getDist(G,1));
    printf("Calling getDist() bad call%d\n", getDist(G,10));
    printf("Calling getpath() \n");

    addArc(G,5,2);
    addArc(G,1,3);
    addArc(G,5,4);
    
    printGraph(stdout, G);

    printf("This is getOrder %d\n", getOrder(G));
    printf("This is getSize %d\n", getSize(G));
    printf("This is getSource %d\n", getSource(G));
    printf("The parent is %d\n", getParent(G,2));
    printf("calling getparent on bad call %d\n", getParent(G,10));
    printf("Calling getDist() %d\n", getDist(G,1));
    printf("Calling getDist() bad call%d\n", getDist(G,10));
    printf("Calling getpath() \n");

    makeNull(G);

    addEdge(G, 1, 3);
    addEdge(G, 1, 2);
    addEdge(G, 1, 5);
    addEdge(G, 2, 3);
    addEdge(G, 5, 3);
    addEdge(G, 1, 3);
    addEdge(G, 3, 3);
    addEdge(G, 2, 4);
    addEdge(G, 2, 5);
    addEdge(G, 4, 3);
    addEdge(G, 4, 5);

    printGraph(stdout, G);


    printf("This is getOrder %d\n", getOrder(G));
    printf("This is getSize %d\n", getSize(G));
    printf("This is getSource %d\n", getSource(G));
    printf("The parent is %d\n", getParent(G,2));
    printf("calling getparent on bad call %d\n", getParent(G,10));
    printf("Calling getDist() %d\n", getDist(G,1));
    printf("Calling getDist() bad call%d\n", getDist(G,10));
    printf("Calling getpath() \n");





    freeList(&l);











    freeGraph(&G);


    return 0;
}