//Servesh Karnawat
//skarnawa
//Pa5
#include<iostream>
#include<string>
#include "List.h"
#include <stdexcept>


#define DUMMY -1






//node constructor
List::Node::Node(ListElement x){
   data = x;
   next = nullptr;
   prev = nullptr;
}


 // Creates new List in the empty state.
List::List(){
   frontDummy = new Node(DUMMY);
   backDummy = new Node(DUMMY);
   beforeCursor = frontDummy;
   afterCursor = backDummy;
   pos_cursor = 0;
   num_elements = 0;

   frontDummy->next = backDummy;
   backDummy->prev = frontDummy;

}
 


// Copy constructor.
List::List(const List& L){
   //start with empty List
   frontDummy = new Node(DUMMY);
   backDummy = new Node(DUMMY);
   beforeCursor = frontDummy;
   afterCursor = backDummy;
   pos_cursor = 0;
   num_elements = 0;

   frontDummy->next = backDummy;
   backDummy->prev = frontDummy;
   //go through each element 

   Node* current = (L.frontDummy)->next;
   while(current != (L.backDummy)) {
      insertBefore(current->data);
      current = current->next;
   }

   //start at the front when done so not at weird position
   moveFront();
   
}

   // Destructor
List::~List(){
   clear();
   delete (frontDummy);
   delete (backDummy);

}


// Access functions --------------------------------------------------------

// length()
// Returns the length of this List.
int List::length() const{
   return num_elements;

}

// front()
// Returns the front element in this List.
// pre: length()>0
ListElement List::front() const{
   if(num_elements<= 0 ){
      throw std::length_error("calling front() on empty list\n");

   }
   else{
      return (frontDummy->next)->data;
   }
}

// back()
// Returns the back element in this List.
// pre: length()>0
ListElement List::back() const{
   if(num_elements<= 0 ){
      throw std::length_error("calling back() on empty list\n");

   }
   else{
      return (backDummy->prev)->data;
   }
}

// position()
// Returns the position of cursor in this List: 0 <= position() <= length().
int List::position() const{
   return pos_cursor;
}

// peekNext()
// Returns the element after the cursor.
// pre: position()<length()
ListElement List::peekNext() const{
   return(afterCursor->data);
}

// peekPrev()
// Returns the element before the cursor.
// pre: position()>0
ListElement List::peekPrev() const{
   return (beforeCursor->data);

}


// Manipulation procedures -------------------------------------------------

// clear()
// Deletes all elements in this List, setting it to the empty state.
void List::clear(){
   moveFront();
   while(num_elements>0){
      eraseAfter();
   }
}

// moveFront()
// Moves cursor to position 0 in this List.
void List::moveFront(){
   beforeCursor = frontDummy;
   afterCursor = frontDummy->next;
   pos_cursor = 0;

}

// moveBack()
// Moves cursor to position length() in this List.
void List::moveBack(){
   beforeCursor = backDummy->prev;
   afterCursor = backDummy;
   pos_cursor = num_elements;

}

// moveNext()
// Advances cursor to next higher position. Returns the List element that
// was passed over. 
// pre: position()<length() 
ListElement List::moveNext(){
   if(pos_cursor >= num_elements){
      throw std::range_error("trying to move next when cursor already at end\n");

   }
   beforeCursor = afterCursor;
   afterCursor = afterCursor->next;
   pos_cursor++;
   return beforeCursor->data;

}

// movePrev()
// Advances cursor to next lower position. Returns the List element that
// was passed over. 
// pre: position()>0
ListElement List::movePrev(){
   if(pos_cursor < 0){
      throw std::range_error("trying to move prev when cursor already at beggining\n");

   }
   afterCursor = beforeCursor;
   beforeCursor = beforeCursor->prev;
   pos_cursor--;
   return afterCursor->data;
}

// insertAfter()
// Inserts x after cursor.
void List::insertAfter(ListElement x){
   Node* N = new Node(x);

   afterCursor->prev = N;
   beforeCursor->next = N;

   N->next = afterCursor;
   N->prev = beforeCursor;
   
   afterCursor = N;
   num_elements++;
   

}

// insertBefore()
// Inserts x before cursor.
void List::insertBefore(ListElement x){
   Node* N = new Node(x);

   afterCursor->prev = N;
   beforeCursor->next = N;
   
   N->next = afterCursor;
   N->prev = beforeCursor;
   
   beforeCursor = N;
   pos_cursor++;
   num_elements++;
   

}

// setAfter()
// Overwrites the List element after the cursor with x.
// pre: position()<length()
void List::setAfter(ListElement x){
   if(pos_cursor >= num_elements){
      throw std::range_error("trying to call setAfter() out of range\n");

   }
   else{
      afterCursor->data = x;
   }
}

// setBefore()
// Overwrites the List element before the cursor with x.
// pre: position()>0
void List::setBefore(ListElement x){
   if(pos_cursor <= 0){
      throw std::range_error("trying to call setbefore() out of range\n");

   }
   else{
      beforeCursor->data = x;
   }
}

// eraseAfter()
// Deletes element after cursor.
// pre: position()<length()
void List::eraseAfter(){
   if(pos_cursor>=length()){
      throw std::range_error("position is not less than length on eraseAfter\n");
   }
   Node* deleted = afterCursor;

   afterCursor = afterCursor->next;
   afterCursor->prev = beforeCursor;
   beforeCursor->next = afterCursor;

   num_elements--;
   delete deleted;
}


// eraseBefore()
// Deletes element before cursor.
// pre: position()>0
void List::eraseBefore(){
   if(pos_cursor<=0){
      throw std::range_error("position is not greater than 0 on eraseBefore\n");
   }
   Node* deleted = beforeCursor;

   beforeCursor = beforeCursor->prev;
   beforeCursor->next = afterCursor;
   afterCursor->prev = beforeCursor;

   pos_cursor--;
   num_elements--;
   delete deleted;
}


// Other Functions ---------------------------------------------------------

// findNext()
// Starting from the current cursor position, performs a linear search (in 
// the direction front-to-back) for the first occurrence of element x. If x
// is found, places the cursor immediately after the found element, then 
// returns the final cursor position. If x is not found, places the cursor 
// at position length(), and returns -1. 
int List::findNext(ListElement x){
   ListElement a;



   while(pos_cursor< num_elements){
      
      a = moveNext();
      if(x== a){
         return pos_cursor;

      }
   }
   
  return -1;
}

// findPrev()
// Starting from the current cursor position, performs a linear search (in 
// the direction back-to-front) for the first occurrence of element x. If x
// is found, places the cursor immediately before the found element, then
// returns the final cursor position. If x is not found, places the cursor 
// at position 0, and returns -1. 
int List::findPrev(ListElement x){
   ListElement a;

   while(pos_cursor> 0){

      a = movePrev();

      if(x == a){

         return pos_cursor;
      }
   }
   



   return -1;



}

// cleanup()
// Removes any repeated elements in this List, leaving only unique elements.
// The order of the remaining elements is obtained by retaining the frontmost 
// occurrance of each element, and removing all other occurances. The cursor 
// is not moved with respect to the retained elements, i.e. it lies between 
// the same two retained elements that it did before cleanup() was called.
void List::cleanup(){

   
   int before = pos_cursor;
   moveFront();
   ListElement current = moveNext();
   

   for(int i = 0; i< num_elements; i++){
      //check each element
      

      //if it is in then delete every instance 
      while (findNext(current)!= -1){
         eraseBefore();
         

         //adjust the cursor if you delete before cursor
         if(pos_cursor < before){
            before--;
         }
      }


      moveFront();
         
      while(pos_cursor < num_elements && pos_cursor <= i ){
         current = moveNext();
         
      }
   }
   moveBack();
   while (pos_cursor > 0 && pos_cursor != before){
      current = movePrev();
   }

}

   //get back to original cursor
   



// concat()
// Returns a new List consisting of the elements of this List, followed by
// the elements of L. The cursor in the returned List will be at postion 0.
List List::concat(const List& L) const{
   
   Node* x = (this->frontDummy)->next;
   List a;
   
   while(x!= (this->backDummy)){
      a.insertBefore(x->data);
      x=x->next;

   }

   Node* y = (L.frontDummy)->next;
   while(y != (L.backDummy)){

      a.insertBefore(y->data);
      y = y->next;


   }
   a.moveFront();
   return a;

}

// to_string()
// Returns a string representation of this List consisting of a comma 
// separated sequence of elements, surrounded by parentheses.
std::string List::to_string() const{
   Node* current = frontDummy->next;
   std::string s = "(";

   while(current != (backDummy->prev)){
      s+= std::to_string(current->data)+", ";
      current = current ->next;

   }
   s += std::to_string(current->data)+")";
   return s;
}

// equals()
// Returns true if and only if this List is the same integer sequence as R.
// The cursors in this List and in R are unchanged.
bool List::equals(const List& R) const{
   if(this->num_elements != R.length()){
      return false;

   }
   
   Node* a = (this->frontDummy)->next;
   Node* b = (R.frontDummy)->next;

   while (a != (this->backDummy)){
      if(a->data != b->data){
         return false;
      }

      a = a->next;
      b = b->next;
   }
   return true;
}


// Overriden Operators -----------------------------------------------------

// operator<<()
// Inserts string representation of L into stream.
std::ostream& operator<<( std::ostream& stream, const List& L ){
   return stream << L.to_string();
}

// operator==()
// Returns true if and only if A is the same integer sequence as B. The 
// cursors in both Lists are unchanged.
bool operator==( const List& A, const List& B ){
   return A.equals(B);
}

// operator=()
// Overwrites the state of this List with state of L.
List& List::operator=( const List& L ){
   if(this != &L){
      clear();
      List temp = L;
      std::swap(frontDummy, temp.frontDummy);
      std::swap(backDummy, temp.backDummy);
      std::swap (beforeCursor, temp.beforeCursor);
      std::swap(afterCursor, temp.afterCursor);
      std::swap(pos_cursor, temp.pos_cursor);
      std::swap(num_elements, temp.num_elements);

   }
   return *this;
}



