//Servesh Karnawat
//skarnawa
//pa4



#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "Matrix.h"
#include "List.h"
const int INF = -1;



typedef struct EntryObj{
    int column;
    double value;

}EntryObj;

typedef struct MatrixObj{
    int size;
    int NNZ;
    List* rows;

} MatrixObj;


Entry newEntry(int column, double value){
    Entry E = malloc(sizeof(EntryObj));
    E->column = column;
    E->value = value;
    return E;
}


void freeEntry(Entry* pE){
    if(pE != NULL && *pE != NULL){
        free(*pE);
        *pE = NULL;
    }
}

Matrix newMatrix(int n){
    Matrix M = malloc(sizeof(MatrixObj));
    M->size = n;
    M->NNZ = 0;
    M->rows = malloc(n * sizeof(List));
    for (int i = 0; i < n ; i++){
        M->rows[i] = newList();

    }
    return M;

}

void freeMatrix(Matrix* pM){
    if(pM != NULL && *pM != NULL){
        //go into each matrix column which has a list
        for(int i = 0; i< (*pM)->size; i++){

            moveFront((*pM)->rows[i]);
            
            //go into each entry in the List 
            while (index((*pM)->rows[i]) >=0){
                Entry E = (Entry)get((*pM)->rows[i]);
                freeEntry(&E);
                moveNext((*pM)->rows[i]);
            }
            //free the List at the column number
            freeList(&((*pM)->rows[i]));
        }
        free((*pM)->rows);
        free(*pM);
        *pM = NULL;


    }
}

int size(Matrix M){
    return M->size;
}

int NNZ (Matrix M){
    return M->NNZ;

}

int equals(Matrix A, Matrix B){
    if(A->size != B->size){
        return 0;

    }
    if(A==NULL || B==NULL){
        return 0;
    }
    if(NNZ(A) != NNZ(B)){
        return 0;
    }
    for (int i = 0 ; i< A->size; i++){
        //compare each row
        List rowA = A->rows[i];
        List rowB= B->rows[i];

        if(length(rowA) != length(rowB)){
            return 0;
        }

        moveFront(rowA);
        moveFront(rowB);

        while (index(rowA)>= 0 && index(rowB)>= 0){
            //get each entry
            Entry EA = (Entry)get(rowA);
            Entry EB = (Entry)get(rowB);
            
            
            if (EA ->column != EB-> column){
                return 0;
            }
            if(EA ->value != EB->value){
                return 0;

            }
            moveNext(rowA);
            moveNext(rowB);

        }
        //make sure entry amounts the same and both -1
        

        
    }
    return 1;

}

void makeZero(Matrix M){
    for (int i = 0; i< M->size; i++){
        List r = M->rows[i];
        moveFront(r);
        while(index(r) >= 0){
            Entry E = (Entry)get(r);
            freeEntry(&E);
            delete(r);
            moveFront(r);

        }
        clear(r);
    }
    M->NNZ = 0;

}

void changeEntry(Matrix M, int i, int j, double x){
    if(i< 1 || i>M->size || j<1 || j>M->size){
        return;
    }
    List currentRow = M->rows[i-1];
    moveFront(currentRow);
    while (index(currentRow) >=0){
        Entry E = (Entry)get(currentRow);
        if(E->column == j){
            //found the thing to change

            //if was something and replace with 0 remove
            if(x==0.0){
                delete(currentRow);
                freeEntry(&E);
                M->NNZ--;
                
            }

            //if was nothing and replace nothing do nothing
            
            //if something and replace something else
            else if(E->value!=0.0 && x!=0.0){
                E->value = x;
            }
            return;
        }
        else if(E->column > j){
            break;
        }
        moveNext(currentRow);

    } 
    //if was nothing and replaced by something 
    if(x != 0){
        Entry E = newEntry(j,x);
        if(index(currentRow) == -1){
            append(currentRow, E);
        }
        else {
            insertBefore(currentRow, E);
            
        }
        M->NNZ++;
    }

}


Matrix copy(Matrix A){
    Matrix C = newMatrix(A->size);
    for (int i = 0; i < A->size; i++){
        List row = A->rows[i];
        moveFront(row);
        while(index(row) >= 0){
            Entry E = (Entry)get(row);
            changeEntry(C, i +1, E->column, E->value);
            moveNext(row);
        }
    
    }
    return C;

}

Matrix transpose(Matrix A){
    Matrix T = newMatrix(A->size);
    for(int i = 0 ; i < A->size ; i++){
        List curRow = A-> rows[i];
        moveFront(curRow);
        while(index(curRow) >= 0){
            Entry E = (Entry)get(curRow);
            //same as copy but swap i and j 
            changeEntry(T, E->column, i+1, E->value);
            moveNext(curRow);

        }
    }
    return T;

}

Matrix scalarMult(double x, Matrix A){
    Matrix S = newMatrix(A->size);
    for (int i= 0; i<A->size; i++){
        List cRow = A->rows[i];
        moveFront(cRow);
        while (index (cRow) >= 0){
            Entry E = (Entry)get(cRow);
            double result = x* E->value;
            if (result != 0.0){
                changeEntry(S, i+1 , E->column, x * E->value);
            }
            moveNext(cRow);


        }
    }
    return S;

}
Matrix sum(Matrix A, Matrix B){
    int co;
    double val;
    int TEA;
    int TEB;
    if(A->size != B-> size){
        return NULL;
    }
    //if the same matrix is plugged into both A and B then 
    //the every call will affect the same matrix twice
    Matrix K = copy(B);
    //the added list
    Matrix S = newMatrix(A-> size);
    for(int i = 0; i < A->size; i++){
        List rowA = A->rows[i];
        List rowB = K->rows[i];
        
        moveFront(rowA);
        moveFront(rowB);
        while(index(rowA) >= 0 || index(rowB) >= 0){
            //in order to get around segfault
            if(index(rowA)>=0){
                TEA = ((Entry)get(rowA))->column;
            }
            else{
                //once EA column index is out of range need the other 
                //EB column to go until it is done so set TEA to "infinity"
                //so that its always bigger than EB
                TEA = INF;
            }
            if(index(rowB) >=0){
                TEB = ((Entry) get(rowB)) -> column;
            }
            else{
                TEB = INF;
            }

            //now check if the other thing is out of index then move EA
            if(TEB == INF){
                Entry EA = (Entry)get(rowA);
                co = EA->column;
                val = EA ->value;
                moveNext(rowA);

            }

            else if (TEA == INF){
                Entry EB = (Entry)get(rowB);
                co = EB->column;
                val = EB->value;
                moveNext(rowB);

            }

            //now regular opperations orders

            //Entry exists in A or A comes before B
            //this one if there is a column A but not column B
            else if (TEA < TEB){
                //A value and 0
                
                Entry EA = (Entry)get(rowA);
                co = EA->column;
                val = EA ->value;
                moveNext(rowA);
                

            }
            //Entry exists on in B or B comes before A
            else if (TEB < TEA){
                
                //B but no A
                Entry EB = (Entry)get(rowB);
                co = EB->column;
                val = EB->value;
                moveNext(rowB);

            }
            //Entry exists in both A and B in same column
            else {
                
                Entry EA = (Entry) get(rowA);
                Entry EB = (Entry) get(rowB);
                co = EA-> column;
                val = (EA->value + EB->value);
                
                moveNext(rowA);
                moveNext(rowB);
                
            }
            
            if(val != 0.0){
                changeEntry(S, i+1, co, val);
            }
            
        }
    }
    freeMatrix(&K);
    return S;
}
Matrix diff(Matrix A, Matrix B){
    if (A->size != B->size) {
        return NULL;

    }
    Matrix D = newMatrix(A->size);
    for (int i = 0 ; i < A->size; i++){
        List rowA = A->rows[i];
        List rowB = B->rows[i];
        moveFront(rowA);
        moveFront(rowB);
        

        while (index(rowA) >= 0 || index (rowB) >= 0){
            int co;
            double val;

            if (index(rowA) >= 0 && (index(rowB) == -1 || ((Entry)get(rowA))->column < ((Entry)get(rowB))->column)){
                Entry EA = (Entry)get(rowA);
                co = EA ->column;
                val = EA->value;
                moveNext(rowA);


            }
            else if(index (rowB) >= 0 && (index(rowA) == -1 || ((Entry)get(rowB))->column < ((Entry)get(rowA))->column)){
                Entry EB = (Entry)get(rowB);
                co = EB ->column;
                val = -EB->value;
                moveNext(rowB);
            }
            else{
                Entry EA = (Entry)get(rowA);
                Entry EB = (Entry)get(rowB);
                co = EA ->column;
                val = EA->value - EB->value;
                moveNext(rowA);
                moveNext(rowB);
            }
            changeEntry(D, i+1, co, val );


        }
    }
    return D;
}

double vectorDot(List P, List Q){
    double dot = 0.0;
    moveFront(P);
    moveFront(Q);

    while(index(P) >= 0 && index(Q) >= 0){
        Entry EP = (Entry)get(P);
        Entry EQ = (Entry)get(Q);
        if (EP ->column == EQ ->column){
            dot += EP->value * EQ ->value;
            moveNext(P);
            moveNext(Q);
        }
        else if (EP->column < EQ->column){
            moveNext(P);


        }
        else{
            moveNext(Q);
        }
    }
    return dot;
}

Matrix product(Matrix A, Matrix B){
    if(A->size != B->size){
        return NULL;
    }
    Matrix P = newMatrix(A->size);
    Matrix T= transpose(B);
    for(int i = 0; i < A->size; i++){
        for(int j = 0; j < A->size; j++){
            double dot = vectorDot(A->rows[i], T->rows[j]);
            if(dot != 0.0){
                changeEntry(P, i+1, j+1, dot);
            }
        }
    }
    freeMatrix(&T);
    return P;
}
void printMatrix(FILE* out, Matrix M){
    for (int i=0; i< M->size ; i++){
        List row = M->rows[i];
        if(length(row) >0){
            fprintf(out, "%d: ", i+1);
            moveFront(row);
            while (index(row) >= 0){
                Entry E = (Entry)get(row);
                fprintf(out, "(%d, %.1f) ", E->column, E->value);
                moveNext(row);

            }
            fprintf(out, "\n");

        }
    }
}



