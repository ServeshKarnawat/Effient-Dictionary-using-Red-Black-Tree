//Servesh Karnawat
//skarnawa
//pa4
Makefile: creates rules to determine which parts of the program need to be recompiled
List.h: instantiates all the functions for the  doubly linked list
List.c: contains actual code defining the functions for the doubly linked list
ListTest.c: tests functions made in List.c
Sparce.c: computes a bunch of Matrix calcultations on sparce matrices in an effient time
Matrix.h: instatiates the functions to be used by Matrix.c
Matrix.c: creates the functions that sparce.c will execute including calulations like sum and diff
MatrixTest.c: tests functions in Matrix.c to make sure they work
