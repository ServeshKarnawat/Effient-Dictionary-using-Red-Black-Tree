//tests
#include "Graph.h"

int main(){
    Graph G= newGraph(5);
    List L = newList();
    Graph A = newGraph(55);






    addArc(A, 54, 1);
    printf("check 1\n");
    addArc(A, 54, 2);
    addArc(A, 54, 2);
    addArc(A, 54, 3);
    printf("check 2\n");
    addArc(A, 1, 54);
    addArc(A, 1, 54);
    printf("check 3\n");
    addArc(A, 1, 55);
    addArc(A, 1, 55);
    printf("the size is %d\n", getSize(A));
    /*if (getSize(A) != 5)
      return 2;
    for (uint8_t i = 1; i <= 100; i++) {
      append(L, i);
    }
    DFS(A, L);
    if (getSize(A) != 5)
      return 3;
    addArc(A, 55, 1);
    if (getSize(A) != 6)
      return 4;
    return 0;
  }*/



    /*

    append(L,1);
    append(L,2);
    append(L,3);
    append(L,4);
    append(L,5);



    addArc(G,1, 4);
    addArc(G,1, 5);
    addArc(G,2, 4);
    addArc(G,3, 4);
    addArc(G,1, 2);
    addArc(G,2, 3);
    printGraph(stdout,G);
    printf("now for the DFS:\n");



    DFS(G, L);

    printf("Now transpose\n");

    Graph T = transpose(G);
    printGraph(stdout,T);
    */




    freeList(&L);
    freeGraph(&G);
    //freeGraph(&T);
    return 0;

}