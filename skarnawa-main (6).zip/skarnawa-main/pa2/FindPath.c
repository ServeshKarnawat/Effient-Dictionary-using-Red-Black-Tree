//Servesh Karnawat
//skarnawa
//pa2
#include "Graph.h"
#include "List.h"


int main (int argc,char* argv[]){
    FILE *inFile = fopen(argv[1], "r");
    if (inFile == NULL){
        fprintf(stderr, "you entered a null file");
        return -1;
    }

    FILE *outFile = fopen(argv[2], "w");


    //read vertices
    int n;
    fscanf(inFile, "%d", &n);
    //create graph
    Graph G = newGraph(n);



    //read the file and make the graph
    int u;
    int v;

    while(fscanf(inFile, "%d %d", &u, &v) == 2){
        if(u == 0 && v == 0  ){
            break;
        }
        addEdge(G, u, v);
    }


    printGraph(outFile, G);

    //read and print the distances:
    while(fscanf(inFile, "%d %d", &u, &v) == 2){
        if(u == 0 && v == 0  ){
            break;
        }
        BFS(G,u);

        //list to store path
        List path = newList();
        getPath(path, G , v);


        if(front(path)== NIL){
            fprintf(outFile, "The distance from %d to %d is infinity\n", u, v);
            fprintf(outFile, "No %d-%d path exists\n", u, v);



        }
        else{
            fprintf(outFile,"The distance from %d to %d is %d\n", u , v, getDist(G,v));
            fprintf(outFile, "A shortest %d-%d path is: ", u, v);
            printList(outFile,path);
            fprintf(outFile, "\n\n");
    }
    
    freeList(&path);
    }

    freeGraph(&G);
    fclose(inFile);
    fclose(outFile);










    return 0;

}