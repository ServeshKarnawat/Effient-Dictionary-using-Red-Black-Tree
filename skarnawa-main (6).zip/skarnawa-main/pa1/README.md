//Servesh Karnawat
//skarnawa
//pa1

List.h: instantiates all the functions for the  doubly linked list

List.c: contains actual code defining the functions for the doubly linked list

ListTest.c: tests cases for the functions in List.c

Lex.c: uses doubly linked list from List.c to sort an inputted file using insertion sort and outputs the sorted list in the outfile

Makefile: creates rules to determine which parts of the program need to be recompiled