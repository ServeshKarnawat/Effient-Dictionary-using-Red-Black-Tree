//Servesh Karnawat
//skarnawa
//pa4


#include "Matrix.h"
#include "List.h"

int main (){
    Matrix A = newMatrix(10);
    Matrix B = newMatrix(10);
    Matrix pC = copy(A);
    Matrix pD = copy(A);
    Matrix T = copy(A);
    changeEntry(A, 1, 1, 4);
    printMatrix(stdout, A);
    changeEntry(A, 1, 2, 2);
    printMatrix(stdout, A);
    changeEntry(A, 1, 3, 0);
    printMatrix(stdout, A);
    changeEntry(A, 2, 1, 2);
    printMatrix(stdout, A);
    changeEntry(A, 3, 1, 0);
    printMatrix(stdout, A);
    changeEntry(A, 2, 2, 2);
    //printf("NNZ is %d\n", NNZ(A));
    printMatrix(stdout, A);
    printf("OG matrix finished:\n");
    changeEntry(A, 3, 3, 0);
    //printf("NNZ is %d\n", NNZ(A));
    printMatrix(stdout, A);
    
    pC = sum(A, A);
    printf("new sum matrix\n");
    printMatrix(stdout, pC);
    
    if (NNZ(pC) != 4 || NNZ(A) != 4)
        return 1;
    printf("checking next test now\n");
    changeEntry(B, 1, 1, -4);
    changeEntry(B, 1, 2, 0);
    changeEntry(B, 2, 1, 0);
    changeEntry(B, 2, 2, -2);
    changeEntry(B, 2, 4, 2);
    changeEntry(B, 3, 1, 0);
    changeEntry(B, 3, 2, 2);
    changeEntry(B, 7, 8, 5);
    printf("still working 1\n");
    pD = sum(A, B);
    printMatrix(stdout,pD);
    printf("NNZ of pD is %d", NNZ(pD));
    if (NNZ(pD) != 5)
        return 2;
        return 0;
    printf("still working 1\n");



    printf("size is %d\n", size(A));

    printf("NNZ is %d\n", NNZ(A));

    printf("equals A A is %d\n", equals(A,A));
    printf("equals A B is %d\n", equals(A,B));

    printf("the transpose is\n");
    printMatrix(stdout,T);

    Matrix scalerA = scalarMult(1.5, A);
    fprintf(stdout, "(1.5)*A =\n");
    printMatrix(stdout, scalerA);
    fprintf(stdout,"\n");
    


    freeMatrix(&A);
    freeMatrix(&scalerA);
    freeMatrix(&T);
    freeMatrix(&B);
    freeMatrix(&pC);
    freeMatrix(&pD);
    return 0;

    
}