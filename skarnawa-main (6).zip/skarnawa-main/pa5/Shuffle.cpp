//Servesh Karnawat
//skarnawa
//Pa5

#include "List.h"
#include <stdexcept>
#include <iostream>
#include <cstdlib>
#include <iomanip>

void shuffle(List& D){
    int n = D.length();
    List firstH;
    List secondH;

    //split in half
    D.moveFront();

    for(int i = 0; i < (n/2); i++){
        firstH.insertBefore(D.moveNext());

    }
    while (D.position() < n){
        secondH.insertBefore(D.moveNext());

    }

    D.clear();

    firstH.moveFront();
    secondH.moveFront();

    while(firstH.position() < firstH.length() || secondH.position() < secondH.length()){
        if(secondH.position()<secondH.length()){
            D.insertBefore(secondH.moveNext());

        }
        if(firstH.position() < firstH.length()){
            D.insertBefore(firstH.moveNext());
        }
    }




    
}

int main (int argc, char* argv[]){
    if(argc != 2){
        return EXIT_FAILURE;

    }

    //atoi is ascii to integer
    int maxSize = atoi(argv[1]);
    if(maxSize <= 0){
        return EXIT_FAILURE;

    }


    std::cout << "deck size       shuffle count\n";
    std::cout << "------------------------------\n";



    for(int i = 1; i<=maxSize; i++){
        //each amount of cards to shuffle
        List deck;

        for(int j = 0; j<i; j++){
            //actually adding cards to shuffle
            deck.insertBefore(j);

        }

        int count = 0;
        List ogDeck = deck;

        //keep shuffling until the decks have become equal again
        while(!(ogDeck.equals(deck)) || count == 0){
         
            shuffle(deck);
            count++;
 

        }

        std::cout<< i << "\t\t" << count << "\n";
        ogDeck.clear();
        deck.clear();
    }
    return 0;
}