//Servesh Karnawat
//skarnawa
//pa4

#include <stdio.h>
#include <stdlib.h>
#include "Matrix.h"
#include "List.h"

int main(int argc, char* argv[]){

    if(argc != 3){
        fprintf(stderr, "wrong amount of input files");
        exit(EXIT_FAILURE);

    }

    FILE* input = fopen(argv[1], "r");
    FILE* output = fopen(argv[2], "w");

    int n;
    int a;
    int b;

    fscanf(input, "%d %d %d", &n, &a, &b);
    Matrix A = newMatrix(n);
    Matrix B = newMatrix(n);


    //read Matrix A
    int row;
    int col;
    double val;
    for (int i = 0; i<a; i++){
        fscanf(input, "%d %d %lf", &row, &col, &val);
        changeEntry(A,row, col, val);
        
        
    }

    //read B
    for (int i = 0; i<a; i++){
        fscanf(input, "%d %d %lf", &row, &col, &val);
        changeEntry(B,row, col, val);
        
        
    }

    fprintf(output, "A has %d non-zero entries:\n", NNZ(A));
    printMatrix(output, A);
    fprintf(output,"\n");

    fprintf(output, "B has %d non-zero entries:\n", NNZ(B));
    printMatrix(output, B);
    fprintf(output,"\n");


    //scalar mult by 1.5
    Matrix scalerA = scalarMult(1.5, A);
    fprintf(output, "(1.5)*A =\n");
    printMatrix(output, scalerA);
    fprintf(output,"\n");

    //A+B
    Matrix sumAB = sum(A, B);
    fprintf(output, "A+B =\n");
    printMatrix(output, sumAB);
    fprintf(output,"\n");

    
    //A+A
    Matrix sumAA = sum(A, A);
    fprintf(output, "A+A =\n");
    printMatrix(output, sumAA);
    fprintf(output,"\n");
    
    
    //B-A
    Matrix diffBA = diff(B,A);
    fprintf(output, "B-A=\n");
    printMatrix(output,diffBA);
    fprintf(output,"\n");

    //A-A
    Matrix diffAA = diff(A,A);
    fprintf(output, "A-A =\n");
    printMatrix(output, diffAA);
    fprintf(output,"\n");


    //Transpose
    Matrix transposeA = transpose(A);
    fprintf(output, "Transpose(A) =\n");
    printMatrix(output, transposeA);
    fprintf(output,"\n");


    //A*B
    Matrix productAB = product(A,B);
    fprintf(output, "A*B = \n");
    printMatrix(output, productAB);
    fprintf(output,"\n");

    //B*B
    Matrix productBB = product(B,B);
    fprintf(output, "B*B = \n");
    printMatrix(output, productBB);
    fprintf(output,"\n");
    



    freeMatrix(&productBB);
    freeMatrix(&productAB);
    freeMatrix(&transposeA);
    freeMatrix(&diffAA);
    freeMatrix(&diffBA);
    freeMatrix(&sumAA);
    freeMatrix(&sumAB);
    freeMatrix(&scalerA);
    freeMatrix(&A);
    freeMatrix(&B);
    fclose(input);
    fclose(output);

    return 0;
}