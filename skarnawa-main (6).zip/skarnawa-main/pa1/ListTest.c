//Servesh Karnawat
//skarnawa
//pa1

#include <stdio.h>
#include "List.h"

int main(){
    List l = newList();

    


    
    append(l,112);
    moveFront(l);
    printList(stdout, l);
    printf("%d\n", length(l));
    printf("%d\n", index(l));
    printf("are we okay?\n");
    delete(l);
    printf("now?\n");

    printf("%d\n", length(l));
    printf("%d\n", index(l));



    printList(stdout, l);

    printf("now1?\n");
    delete(l);
    printf("now2?\n");
    append (l, 10);
    printf("now3?\n");
    append (l, 3000);
    printf("now4?\n");
    printList(stderr,l);
    moveBack(l);
    printf("moved back\n");
    printf("len %d\n", length(l));
    printf("i %d\n", index(l));

    delete(l);
    printf("now5?\n");
    delete(l);
    delete(l);

    printList(stderr,l);



   //test delete when at front
   append(l, 140);
   append(l, 120);
   printf("added two things\n");
   printList(stdout,l);
   moveBack(l);
   delete(l);
   printf("deleted the back\n");
   printList(stdout,l);

   //delete from middle
   printf("added two more things\n");
   append(l, 200);
   append(l, 80);
   printList(stdout,l);

   printf("moving to middle and deleting \n");
   moveFront(l);
   moveNext(l);
   delete(l);
   printList(stdout,l);

   //delete back

   moveBack(l);
   delete(l);
   printList(stdout,l);




    printf("beggining the tests\n");
    printf("%d",length(l));
    printf("\n%d",index(l));
    printf("\n%d",front(l));
    printf("\n%d",back(l));
    printf("\nabout to add stuff\n");

    append(l,13);
    append(l,1);
    printf("\nadded stuff\n");
    printf("%d",length(l));
    printf(" is the length \n");
    printList(stdout, l);
    printf("index: %d\n",index(l));
    printf("this is the front %d\n",front(l));
    printf("this is the back %d\n",back(l));
    deleteFront(l);
    printf("index: %d\n",index(l));
    printf("this should have deleted the front now printing new list\n");
    printList(stdout, l);
    printf("the length is now: ");
    printf("%d\n", length(l));
    append(l, 40);
    printList(stdout, l);
    printf("index: %d\n",index(l));
    printf("%d\n",index(l));
    moveFront(l);
    printf("%d\n", index(l));
    moveNext(l);
    printf("index: %d\n",index(l));
    movePrev(l);
    printf("index: %d\n",index(l));
    movePrev(l);
    printf("index: %d\n",index(l));
    moveBack(l);
    printf("index: %d\n",index(l));
    printList(stdout, l);
    set(l, 12);
    printList(stdout, l);
    printf("index: %d\n",index(l));
    printf("front: %d\n",front(l));
    printf("index: %d\n",index(l));
    printf("back: %d\n",back(l));
    printf("going to call get\n");
    get(l);
    printf("prepending 560\n");

    prepend(l, 560);
    printList(stdout, l);
    printf("moving back\n");
    moveBack(l);
    printf("calling insert before\n");
    insertBefore(l, 20);
    printList(stdout,l);
    printf("insert after -50\n");
    insertAfter(l, -50);
    printList(stdout,l);
    printf("deletefront\n");
    deleteFront(l);
    printList(stdout,l);
    printf("delete back\n");
    deleteBack(l);
    printList(stdout,l);
    printf("copying list\n");
    List w = copyList(l);
    printf("are they equal\n");
    printf("1 true 0 false:\n %d\n", equals(w,l));
    printf("calling delete on l\n");
    delete(l);
    printList(stdout,l);
    printf("now should not be equal\n");
    printf("%d\n", equals(w,l));
    printf("calling clear\n");
    clear(l);
    printf("final print list for l\n");
    printList(stdout,l);
    printf("i think everything works\n");









    
    freeList(&w);

    
    freeList(&l);
    //freeList(&A);


    return 0;
}