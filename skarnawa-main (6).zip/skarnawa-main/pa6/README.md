//Servesh Karnawat
//skarnawa
//pa6

Makefile: creates rules to determine which parts of the program need to be compiled
List.h: instantiates all the functions for the List ADT in C++
List.cpp: has the actual code to run the functions declared in List.h
ListTest.cpp: Tests my functions made in List.cpp
BigInteger.h: instantiates all the functions for the BigInteger ADT 
BigInteger.cpp: has the actual program for the functions for BigInteger
BigIntegerTest.cpp: where I test my BigInteger functions 
Arithmetic.cpp: demonstrates the functions created in BigInteger.cpp by calcualting equations with very large numbers. 